<?php
function callpage($page, $title="") {
    include_once("pages/$page.php");
}
?>